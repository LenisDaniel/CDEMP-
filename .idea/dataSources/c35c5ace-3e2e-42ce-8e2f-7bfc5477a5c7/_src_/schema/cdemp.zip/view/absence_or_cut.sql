CREATE VIEW absence_or_cut AS
  SELECT
    `dr`.`daily_record_id` AS `daily_record_id`,
    `dr`.`teacher_id`      AS `teacher_id`,
    `dr`.`student_id`      AS `student_id`,
    `dr`.`grade_id`        AS `grade_id`,
    `dr`.`group_id`        AS `group_id`,
    `dr`.`course_id`       AS `course_id`,
    `dr`.`day_status_id`   AS `day_status_id`,
    `dr`.`incident_id`     AS `incident_id`,
    `dr`.`create_date`     AS `create_date`,
    `st`.`day_hour_id`     AS `day_hour_id`
  FROM (`cdemp`.`daily_records` `dr`
    JOIN `cdemp`.`schedules_teacher` `st` ON ((
      (`st`.`grade_id` = `dr`.`grade_id`) AND (`st`.`group_id` = `dr`.`group_id`) AND
      (`st`.`course_id` = `dr`.`course_id`) AND (`st`.`teacher_id` = `dr`.`teacher_id`))))
  GROUP BY `dr`.`student_id`, `dr`.`create_date`
  ORDER BY `dr`.`create_date`;
